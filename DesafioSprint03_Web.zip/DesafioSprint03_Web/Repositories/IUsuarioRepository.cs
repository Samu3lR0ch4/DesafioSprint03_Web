﻿using DesafioSprint03_Web.Models;
namespace DesafioSprint03_Web.Repositories
{
    public interface IUsuarioRepository
    {

        Task<Usuario?> BuscarPorNome(string Nome);

        Task Adicionar(Usuario usuario);
    }
}
